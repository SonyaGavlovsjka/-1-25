﻿class Program
{
    static void Main()
    {
        Console.Write("Введiть розмiр масиву - ");
        int n = Convert.ToInt32(Console.ReadLine());

        if (n < 20 || n > 500)
        {
            Console.WriteLine("Помилка: розмiр повинен бути вiд 20 до 500!");
            return;
        }

        int[] m = new int[n];

        Console.WriteLine("Ввеiть елементи масиву:");

        for (int i = 0; i < n; i++)
        {
            Console.Write("");
            m[i] = Convert.ToInt32(Console.ReadLine());
        }

        Array.Sort(m);
        Array.Reverse(m);

        Console.WriteLine("\nМасив за спаданням:");
        Console.WriteLine(string.Join(" ", m));

        int sum = 0;

        foreach (int num in m)
            if (num % 2 == 0) sum += num;

        Console.WriteLine($"\nСума парних елементiв: {sum}");
    }
}
