﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введiть число n: ");// вводимо значення для N
        int n = int.Parse(Console.ReadLine());

        int a = 0;
        int b = 1;
        int sum = 0;

       
        while (a < n)
        {
            sum += a; // додаємо до суми
            int t = a + b; // обчислюємо наступне число
            a = b;
            b = t;
        }

        Console.WriteLine($"Сума чисел Фiбоначчi менших за {n} = {sum}");// виводимо результат
    }
}

