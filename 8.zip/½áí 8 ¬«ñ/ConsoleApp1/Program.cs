﻿using System;

class Program
{
    static void Main()
    {
        int n = 30;                                 
        int[] m = new int[n];                   
        Random r = new Random();                

      
        for (int i = 0; i < n; i++)
            m[i] = r.Next(-25, 26);           

        Console.WriteLine("Початковий масив:");
        Console.WriteLine(string.Join(" ", m));  

      
        Array.Sort(m);

        Console.WriteLine("\nВiдсортований за зростанням масив:");
        Console.WriteLine(string.Join(" ", m));  

      
        int min = m[0];                   
        int max = m[m.Length - 1];         
        int d = max - min;                

        Console.WriteLine($"\nМiнiмальний елемент: {min}");
        Console.WriteLine($"Максимальний елемент: {max}");
        Console.WriteLine($"Рiзниця мiж максимальним i мiнiмальним: {d}");
    }
}
