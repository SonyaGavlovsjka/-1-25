﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Введiть число: ");
            double number = Convert.ToDouble(Console.ReadLine());

            if (number < 0)
            {
                Console.WriteLine("Помилка: не можна обчислити квадратний корiнь з вiд’ємного числа.");
            }
            else
            {
                double result = Math.Sqrt(number);
                Console.WriteLine("Квадратний корiнь: " + result);
            }
        }
        catch
        {
            Console.WriteLine("Помилка: введено некоректне значення!");
        }
    }
}
