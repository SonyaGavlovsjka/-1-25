﻿/*using System;

class Program // Оголошення класу
{
    static void Main() // Головний метод
    {
        Console.Write("Введiть значення x: ");
        double x = Convert.ToDouble(Console.ReadLine()); // Введення з клавіатури та перетворення в число

        double y = Math.Sin(5 * x); // Обчислення y = sin(5x)

        Console.WriteLine("Вираз 1: y = sin(5x)");
        Console.WriteLine("x = {0}; y = {1}", x, y); // Вивід результату
    }
}
*/
using System; 

class Program // Оголошення класу
{
    static void Main()
    {
        Console.Write("Введіть значення x: ");
        double x = Convert.ToDouble(Console.ReadLine()); // Введення з клавіатури та перетворення в число
        double sum = Math.Cos(x) + Math.Sin(x); // Обчислення суми косинуса і синуса від x
        double y = Math.Abs(sum);    // Обчислення абсолютного значення суми 
        Console.WriteLine("Вираз 2: y = |cos(x) + sin(x)|");
        Console.WriteLine("x = {0}; y = {1}", x, y);// Виведення результату ( 0 заміняється на х, 1 заміняється на у)
    }
}
