﻿using System;

class Program
{
    static void Main()
    {
      
        int a, x, t;     // цілі числа
        double b;        // число з плаваючою комою подвійної точності
        float c;         // число з плаваючою комою одинарної точності

        // Введення значень з клавіатури
        Console.Write("Введiть a (int): ");
        a = int.Parse(Console.ReadLine());  

        Console.Write("Введiть x (int): ");
        x = int.Parse(Console.ReadLine());

        Console.Write("Введiть t (int): ");
        t = int.Parse(Console.ReadLine());

        Console.Write("Введiть b (double): ");
        b = double.Parse(Console.ReadLine()); 

        Console.Write("Введiть c (float): ");
        c = float.Parse(Console.ReadLine());  

        Console.WriteLine("\nПеревiрка та обчислення:");

        // Вираз 1 
        if (a > 0 && x > 0 && t > 0)  // перевірка 
        {
            Console.WriteLine($"1) a * 2 + x * t + a =  {a * 2 + x * t + a}");// обчислення і виведення виразу
        }
        else
        {
            Console.WriteLine("a, x, t мають  бути бiльшi за 0");
        }

        // Вираз 2 
        if (t == 0 || a > 0 && x >0 && c > 0) 
        {
            Console.WriteLine($"2) (c + a) + x / t = {(c + a) + x / t}");
        }
        else
        {
            Console.WriteLine("2) t, a, x, c мають  бути бiльшi за 0");
        }

        // Вираз 3
        if (a > 0 && b > 0 && x>0) 
        {
            Console.WriteLine($"3)(a / b * (a + x / b) / (a * b) = ) {(a / b * (a + x / b) / (a * b))}");
        }
        else
        {
            Console.WriteLine("3) a, b, x мають  бути бiльшi за 0");
        }
    }
}
